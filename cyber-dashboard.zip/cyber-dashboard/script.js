const buttons = document.querySelectorAll(".nav-btn");
const sidePanel = document.getElementById("sidePanel");
const systemStatus = document.getElementById("systemStatus");
const energyLevel = document.getElementById("energyLevel");
const lastAction = document.getElementById("lastAction");
const statusText = document.getElementById("statusText");

const clockElement = document.getElementById("clock");
const dateElement = document.getElementById("date");

const bootScreen = document.getElementById("bootScreen");
const startBtn = document.getElementById("startBtn");

let energy = 100;
let alertActive = false;

/* BOOT */
startBtn.addEventListener("click", () => {
    bootScreen.classList.add("hidden");
    setTimeout(() => bootScreen.style.display = "none", 700);
});

/* RELÓGIO */
function updateDateTime() {
    const now = new Date();

    const h = String(now.getHours()).padStart(2, "0");
    const m = String(now.getMinutes()).padStart(2, "0");
    const s = String(now.getSeconds()).padStart(2, "0");
    clockElement.textContent = `${h}:${m}:${s}`;

    const d = String(now.getDate()).padStart(2, "0");
    const mo = String(now.getMonth() + 1).padStart(2, "0");
    const y = now.getFullYear();
    dateElement.textContent = `${d}/${mo}/${y}`;
}
setInterval(updateDateTime, 1000);
updateDateTime();

/* PAINEL */
function updatePanel(action) {
    lastAction.textContent = action;
    energyLevel.textContent = energy + "%";
}

/* SCAN */
function simulateScan() {
    systemStatus.textContent = "ESCANEANDO...";
    let progress = 0;

    const interval = setInterval(() => {
        progress += 10;
        energy -= 1;
        energyLevel.textContent = energy + "%";

        if (progress >= 100) {
            clearInterval(interval);
            systemStatus.textContent = "ALVO IDENTIFICADO";
            updatePanel("Escaneamento concluído");
        }
    }, 200);
}

/* RESET */
function resetSystem() {
    energy = 100;
    systemStatus.textContent = "ONLINE";
    statusText.textContent = "ONLINE";
    document.body.classList.remove("alert-mode");
    alertActive = false;
    updatePanel("Sistema resetado");
}

/* BOTÕES */
buttons.forEach(btn => {
    btn.addEventListener("click", () => {

        const action = btn.dataset.action;

        buttons.forEach(b => b.classList.remove("active"));
        btn.classList.add("active");

        switch(action) {

            case "menu":
                sidePanel.classList.toggle("open");
                updatePanel("Painel alternado");
                break;

            case "scan":
                simulateScan();
                break;

            case "energy":
                energy -= 10;
                if (energy < 0) energy = 0;
                updatePanel("Consumo de energia");
                break;

            case "alert":
                alertActive = !alertActive;
                document.body.classList.toggle("alert-mode");

                if (alertActive) {
                    systemStatus.textContent = "OFFLINE";
                    statusText.textContent = "OFFLINE";
                    updatePanel("ALERTA CRÍTICO");
                } else {
                    systemStatus.textContent = "ONLINE";
                    statusText.textContent = "ONLINE";
                    updatePanel("Alerta desativado");
                }
                break;

            case "reset":
                resetSystem();
                break;
        }
    });
});